"use client";
import React from "react";
import { motion } from "framer-motion";

export default function HomePage() {
  return (
    <main className="min-h-screen bg-white text-gray-900">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-yellow-500 to-red-500 text-white py-24 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <motion.h1
            className="text-5xl font-bold mb-6"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            AJF Empilhadeiras
          </motion.h1>
          <p className="text-lg mb-6">
            Soluções completas em vendas, locação e manutenção de empilhadeiras.
          </p>
          <button className="bg-white text-red-600 font-semibold py-3 px-8 rounded-full hover:bg-gray-100 transition">
            Solicite um Orçamento
          </button>
        </div>
      </section>

      {/* Sobre a Empresa */}
      <section className="py-16 px-6 bg-gray-100">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-semibold mb-4">Sobre Nós</h2>
          <p className="text-gray-700">
            Com anos de experiência no mercado, a AJF Empilhadeiras oferece serviços de excelência na área de movimentação de cargas, garantindo confiança, segurança e agilidade para sua empresa.
          </p>
        </div>
      </section>

      {/* Serviços */}
      <section className="py-16 px-6">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl font-semibold text-center mb-10">Nossos Serviços</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {["Venda", "Locação", "Manutenção"].map((servico, idx) => (
              <div key={idx} className="bg-white shadow p-6 text-center rounded-xl">
                <h3 className="text-xl font-bold mb-2">{servico} de Empilhadeiras</h3>
                <p className="text-gray-600">
                  Oferecemos soluções sob medida para sua operação, com atendimento rápido e peças de qualidade.
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contato */}
      <section className="bg-gray-100 py-16 px-6">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-semibold mb-6">Fale Conosco</h2>
          <p className="mb-4">
            Estamos prontos para atender você. Preencha o formulário e entraremos em contato o mais breve possível.
          </p>
          <form className="grid grid-cols-1 gap-4">
            <input className="p-4 rounded border" type="text" placeholder="Seu nome" required />
            <input className="p-4 rounded border" type="email" placeholder="Seu e-mail" required />
            <textarea className="p-4 rounded border" placeholder="Sua mensagem" rows={4} required></textarea>
            <button className="bg-red-600 text-white py-3 rounded hover:bg-red-700 transition">
              Enviar Mensagem
            </button>
          </form>
        </div>
      </section>

      {/* Rodapé */}
      <footer className="bg-gray-800 text-white text-center py-6">
        <p>&copy; {new Date().getFullYear()} AJF Empilhadeiras. Todos os direitos reservados.</p>
      </footer>
    </main>
  );
}